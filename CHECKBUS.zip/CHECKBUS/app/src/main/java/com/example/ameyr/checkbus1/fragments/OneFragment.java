package com.example.ameyr.checkbus1.fragments;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.ameyr.checkbus1.R;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;


public class OneFragment extends Fragment {
    String myJSON;
    Context context;
    private static final String TAG_RESULTS="result";
    private static final String TAG_ID = "Bus Id";
    private static final String TAG_NAME = "Route Name";
    private static final String TAG_ROUTE_NO ="Route No";
    private static final String TAG_TIME ="Time";
    private static final String TAG_Latitude ="Latitude";
    private static final String TAG_Longitude ="Longitude";

    JSONArray peoples = null;

    ArrayList<HashMap<String, String>> alldataList;


    ListView ll_search_result;
    public OneFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_one, container, false);
        alldataList = new ArrayList<HashMap<String,String>>();
        ll_search_result = (ListView) view.findViewById(R.id.ll_search_result);
        ll_search_result.setDivider(null);
        myJSON = null;
        populateList();
        return view;
    }

    private void populateList() {
        getListFromServer();
       /* AllSearchBus_Adapter allSearchBus_adapter = new AllSearchBus_Adapter(getContext(),1);
        ll_search_result.setAdapter(allSearchBus_adapter);*/

    }

    private void getListFromServer() {
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {
                DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
                HttpPost httppost = new HttpPost("http://bustrackinglocation.16mb.com/trackbus/home.php");

                // Depends on your web service
                httppost.setHeader("Content-type", "application/json");

                InputStream inputStream = null;
                String result = null;
                try {
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity entity = response.getEntity();

                    inputStream = entity.getContent();
                    // json is UTF-8 by default
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                    StringBuilder sb = new StringBuilder();

                    String line = null;
                    while ((line = reader.readLine()) != null)
                    {
                        sb.append(line + "\n");
                    }
                    result = sb.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                finally {
                    try{if(inputStream != null)inputStream.close();}catch(Exception squish){}
                }
                return result;
            }

            @Override
            protected void onPostExecute(String result){
                myJSON=result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute();

    }

    private void showList() {
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            peoples = jsonObj.getJSONArray(TAG_RESULTS);

            for(int i=0;i<peoples.length();i++){
                JSONObject c = peoples.getJSONObject(i);
                String id = c.getString(TAG_ID);
                String name = c.getString(TAG_NAME);
                String route_no = c.getString(TAG_ROUTE_NO);
                String time = c.getString(TAG_TIME);
                String longitude = c.getString(TAG_Longitude);
                String latitude = c.getString(TAG_Latitude);

                HashMap<String,String> persons = new HashMap<String,String>();

                persons.put(TAG_ID,id);
                persons.put(TAG_NAME,name);
                persons.put(TAG_ROUTE_NO,route_no);
                persons.put(TAG_TIME,time);
                persons.put(TAG_Latitude,latitude);
                persons.put(TAG_Longitude,longitude);

                alldataList.add(persons);
            }
           /* adapter = new PurchaseHistoryAdapter(PurchaseHistory.this, purchase_history_list);
            lv_purchasehistory.setAdapter(adapter);
            ListAdapter adapter = new SimpleAdapter(
                    context, alldataList, R.layout.allsearchbus_adapterview,
                    new String[]{TAG_ID,TAG_ROUTE_NO,TAG_NAME,TAG_TIME,TAG_Latitude,TAG_Longitude},
                    new int[]{R.id.tv_subname, R.id.tv_itemname, R.id.tv_custcount}
            );

            ll_search_result.setAdapter(adapter);
*/
            AllSearchBus_Adapter allSearchBus_adapter = new AllSearchBus_Adapter(getContext(),1,alldataList);
            ll_search_result.setAdapter(allSearchBus_adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}
