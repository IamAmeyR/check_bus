package com.example.ameyr.checkbus1.fragments;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.ameyr.checkbus1.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by AmeyR on 1/22/2017.
 */
public class AllSearchBus_Adapter extends ArrayAdapter {

    Context context;
    List<HashMap<String, String>> allDataList;
    static Dialog loading_dialog;
    Typeface typeface_Mono;


    public AllSearchBus_Adapter(Context context, int resource, ArrayList<HashMap<String, String>> alldataList) {
        super(context, resource);
        this.context = context;
        this.allDataList=alldataList;
      //  typeface_Mono = Typeface.createFromAsset(context.getAssets(), "Roboto-Light.ttf");
    }

    @Override
    public int getCount() {

        int count = allDataList.size();
        return count;
    }

    @Override
    public Object getItem(int position) {

        int count = allDataList.size();
        return count;
    }

    @Override
    public long getItemId(int position) {

        return 0;
    }

    static class ViewHolder {

        TextView subscriptionname;
        TextView itemnname;
        TextView custcount;
        TextView qtycount;
        TextView bus_time;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {


        final ViewHolder viewHolder;

        // added try catch 11 mar 16
        try {

            if (convertView == null) {
                viewHolder = new ViewHolder();
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.allsearchbus_adapterview, null, true);
              //  typeface_Mono = Typeface.createFromAsset(context.getAssets(), "Roboto-Light.ttf");

                viewHolder.subscriptionname = (TextView) convertView.findViewById(R.id.tv_subname);
                viewHolder.itemnname = (TextView) convertView.findViewById(R.id.tv_itemname);
                viewHolder.custcount = (TextView) convertView.findViewById(R.id.tv_custcount);
                viewHolder.qtycount = (TextView) convertView.findViewById(R.id.tv_quantity);
                viewHolder.bus_time = (TextView) convertView.findViewById(R.id.bus_time);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
           // viewHolder.subscriptionname.setTypeface(typeface_Mono);
           // viewHolder.itemnname.setTypeface(typeface_Mono);
           // viewHolder.custcount.setTypeface(typeface_Mono);
           // viewHolder.qtycount.setTypeface(typeface_Mono);
/*
            viewHolder.subscriptionname.setText("Tambaram -> Beach");
            viewHolder.itemnname.setText("123");
            viewHolder.custcount.setText("456");
            viewHolder.qtycount.setText("789");
            viewHolder.bus_time.setText("12:30");*/


            viewHolder.subscriptionname.setText(allDataList.get(position).get("Bus Id")+" - "+allDataList.get(position).get("Route Name"));
            viewHolder.itemnname.setText(allDataList.get(position).get("Route No"));
            viewHolder.custcount.setText(allDataList.get(position).get("Latitude"));
            viewHolder.qtycount.setText(allDataList.get(position).get("Longitude"));
            viewHolder.bus_time.setText(allDataList.get(position).get("Time"));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return convertView;
    }
}